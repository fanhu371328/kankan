;(function($){
	var check = $(".check").val();

	function hideone() {
		$("#imgone").css("display", "none")
	}
	$(".get").click(function() {
		var d = $(".text").val(),
			b = $(".text").val();
		if("" == b) return $("#imgone").css("display", "block"), setTimeout(hideone, 2E3), !1;
		if(/^1[3|4|5|7|8][0-9]{9}$/.test(b)) {
			$.ajax({
				url: "http://m.ruthout.com/ruth/user/getPhoneCode",
				type: "post",
				data: {
					account: b
				},
				success: function(a) {
					console.log(a);
					$.cookie("vcode", a.vcode);
					$.cookie("tel", d)
				}
			});
			var a = 60,
			c = setInterval(function() {
				$("#btn_yzm").attr("disabled", !0);
				$("#btn_yzm").val("\u5df2\u53d1\u9001(" + a + "s)");
				0 == a && ($("#btn_yzm").val("\u91cd\u65b0\u53d1\u9001").removeAttr("disabled"),
					clearInterval(c));
				a--
			}, 1E3)
		} else return $("#imgone img").attr("src", "../images/sjhgsbzq@3x.png"), $("#imgone").css("display", "block"), setTimeout(hideone, 2E3), !1
	});
	$(".button").click(function() {
		var d = $.cookie("vcode");
		$.cookie("the_cookie");
		var b = $(".text").val(),
			a = $(".check").val(),
			c = $(".password").val();
			if("" == b) return $("#imgone").css("display", "block"), setTimeout(hideone, 2E3), !1;
			if("" == a) return $("#imgone img").attr("src", "../images/yzmbnwk@3x.png"), $("#imgone").css("display", "block"), setTimeout(hideone, 2E3), !1;
			if(a != d) return $("#imgone img").attr("src", "../images/yzmbzq@3x.png"), $("#imgone").css("display", "block"), setTimeout(hideone, 2E3), !1;
			if("" == c) return $("#imgone img").attr("src", "../images/mmbnwk@3x.png"), $("#imgone").css("display", "block"), setTimeout(hideone, 2E3), !1;
			if(/^(\w|\d){6,16}$/.test(c)) b = $(".text").val(), a = $(".check").val(), c = $(".password").val(), $.ajax({
			url: "http://m.ruthout.com/ruth/user/userRegist",
			type: "post",
			data: {
				account: b,
				phonCode: a,
				passWord: c
			},
			success: function(a) {
				0 == a.success ? ($("#imgone img").attr("src", "../images/yibeizhuce@3x.png"), $("#imgone").css("display", "block"), setTimeout(hideone, 2E3)) :
					location.href = "login_page.html"
			}
		});
		else return $("#imgone img").attr("src", "../images/mmgsbzq@3x.png"), $("#imgone").css("display", "block"), setTimeout(hideone, 2E3), !1
	});


})(jQuery)
