function hideone() {
	$("#imgone").css("display", "none")
}

function hidetwo() {
	$("#imgtwo").css("display", "none")
}
$(".button").click(function() {
	var c = $(".text").val(),
		d = $(".password").val();
	if("" == c || "" == d) return $("#imgone").css("display", "block"), setTimeout(hideone, 2E3), !1;
	$.ajax({
		url: "http://m.ruthout.com/ruth/user/login",
		type: "post",
		data: {
			account: c,
			passWord: d
		},
		success: function(a) {
			if(0 == a.success) return $("#imgtwo").css("display", "block"), setTimeout(hidetwo, 2E3), !1;
			setCookie("the_cookie", a.userInfo.userId, 1800);
			window.location.href = "../choujiang.html"
		}
	})
});
$(".return").on("click", function() {
	window.location.href = "../cj.html"
});

function setCookie(c, d, a) {
	a = a || 0;
	var b = "";
	0 != a && (b = new Date, b.setTime(b.getTime() + 1E3 * a), b = "; expires=" + b.toGMTString());
	document.cookie = c + "=" + escape(d) + b + "; path=/"
};