
;(function($){
	//------------------------------------------------
	$(".main-bottom-top span").on("click",function(){
		var index=$(this).index();
		$(".main-bottom-top span").removeClass("active");
		$(this).addClass("active");
		if(index == 0) {
			$(".main-bottom-bot .right").hide();
			$(".main-bottom-bot .left").show();
		}else if (index == 1){
			$(".main-bottom-bot .right").show();
			$(".main-bottom-bot .left").hide();
		}
	})
	
	$(".share-icon").on("click",function(){
		var u = navigator.userAgent;
		alert(u);
		if(u.indexOf('Mobile') >= 0){
			if(u.indexOf('MicroMessenger') == -1){
				$(".share-main1 .top").hide();
				$(".share-main1 .bottom").show();
			}
		} else {
			alert('请使用手机浏览器进行分享');
			return false;
		}
		$(".share-main1").show();
	})
	$(".share-main1").on("click",function(){
		$(this).hide()
	})
	
	//滚动效果一------------------------------------
//		setInterval(_scroll1,3000);
		
		function _scroll1(){
			$('.left li').addClass('fadeInUp');
			var _first = $('.left li').eq(0).html();
			$('.left li:first').remove();
			$('.left').append('<li class="animated">'+_first+'</li>');
			setTimeout(function(){
				$('.left li').removeClass('fadeInUp');
			},1000)
		}
	//效果一结束-------------------------------------
	
	//效果二---如果使用第二种方法li中animated类名可以去掉
	setInterval(function(){
		_scroll(".main-bottom-bot");
	},1000);
	
	function _scroll(obj){
		$(obj).find(".left").animate({  
			marginTop : "-.3rem"
		},1000,'linear',function(){  
			$(this).css({marginTop : "0px"}).find("li:first").appendTo(this);  
		}) 
	}
	//效果二结束--------------------------------------
	
	
	//分享
//	wx.ready(function (){
//      var shareData =
//      {
//          title: "新年大作战--欢乐转不停！",
//          desc: "考验人品的时候到了~",
//          link: "https://www.baidu.com/" ,
//          imgUrl: "https://yuntouhui.cn/weixin/images/newyear/redbag.png",
//          success: function ()
//          {
//          },
//          cancel: function ()
//          {
//          }
//      };
//
//      wx.onMenuShareTimeline(shareData);
//      wx.onMenuShareAppMessage(shareData);
//      wx.onMenuShareQQ(shareData);
//      wx.onMenuShareWeibo(shareData);
//      wx.onMenuShareQZone(shareData);
//  });
	
	
	
	
	
	
	
	
	
	
	
})(jQuery)
